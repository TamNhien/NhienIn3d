import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { CoSoDuLieuModule } from "./co-so-du-lieu/co-so-du-lieu.module.js";
import { SucKhoeModule } from "./suc-khoe/suc-khoe.module.js";
import { DanhMucModule } from "./danh-muc/danh-muc.module.js";
import { SanPhamModule } from "./san-pham/san-pham.module.js";
import { XacThucModule } from "./xac-thuc/xac-thuc.module.js";
import { GioHangModule } from "./gio-hang/gio-hang.module.js";
import { ThanhToanModule } from "./thanh-toan/thanh-toan.module.js";
import { YeuThichModule } from "./yeu-thich/yeu-thich.module.js";
import { DanhGiaModule } from "./danh-gia/danh-gia.module.js";
import { TaiKhoanModule } from "./tai-khoan/tai-khoan.module.js";
import { QuanTriModule } from "./quan-tri/quan-tri.module.js";

@Module({
  imports: [ConfigModule.forRoot({ isGlobal: true }), CoSoDuLieuModule, SucKhoeModule, DanhMucModule, SanPhamModule, XacThucModule, GioHangModule, ThanhToanModule, YeuThichModule, DanhGiaModule, TaiKhoanModule, QuanTriModule]
})
export class AppModule {}
